package in.cg.entities;

import java.util.List;

import jakarta.persistence.*;

@Entity
@Table
public class Trainer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(
			name="Trainer_CourseTable",
			joinColumns=@JoinColumn(name="Trainer_id"),
			inverseJoinColumns=@JoinColumn(name="Course_id")
			)
	List<Courses> courses;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Courses> getCourses() {
		return courses;
	}

	public void setCourses(List<Courses> courses) {
		this.courses = courses;
	}
	
}
