package in.cg.liveCode1;
import java.util.Arrays;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import in.cg.entities.Courses;
import in.cg.entities.Trainer; class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Welcome To my World" );
        Configuration cfg=new Configuration();
        cfg.configure("in/cg/config/hibernate.cfg.xml");
        SessionFactory sf=cfg.buildSessionFactory();
        Session s=sf.openSession();
        Transaction tr=s.beginTransaction();
        Courses c1=new Courses();
        c1.setName("Junit");
        Courses c2=new Courses();
        c1.setName("Mockito");
        Trainer t1=new Trainer();
        t1.setCourses(Arrays.asList(c1,c2));
        t1.setName("Lakshmi");
        try {
        s.persist(t1);
        tr.commit();
        }
        catch(Exception e) {
        	tr.rollback();
        	e.printStackTrace();
        }
    }
}